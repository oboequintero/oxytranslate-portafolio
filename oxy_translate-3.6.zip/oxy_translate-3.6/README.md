# Oxygen en Español #

Plugin para traducir Oxygen al español

## Instalación ##
....................................................................................................
1. Click on the `Download ZIP` button at the right to download the plugin.
2. Go to Plugins > Add New in your WordPress admin. Click on `Upload Plugin` and browse for the zip file.
3. Activate the plugin.

