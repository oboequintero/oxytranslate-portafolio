<?php
class oxy_borrar_tabla {

	
	public static function deactivate() {
        
        #flush_rewrite_rules();
        
    }

}
