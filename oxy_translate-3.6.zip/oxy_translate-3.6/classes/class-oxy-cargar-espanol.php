<?php

class oxy_idioma_espanol {

function re_cargar_idioma_espanol() { 
   $dir = WP_CONTENT_DIR . '\languages\plugins\*';
    // Abrir un directorio, y proceder a leer su contenido
    foreach(glob($dir) as $file) {
       #echo "filename:" . $file . "<br />";   
       #$cadena = 'oxygen';   # viene de la funcion str
       $cadena_oxygen= substr($file, -15 ,6);
      
       if($cadena_oxygen == 'oxygen')# si la cadena coincide, buscamos el locale
       {    
            $this->cargar_idioma_espanol();
       }

       }// end glob
}
    
function cargar_idioma_espanol() { 
    

    $oxy_mo = WP_CONTENT_DIR . '\languages\plugins\oxygen-'. get_locale().'.mo';
    $ct_mo = WP_CONTENT_DIR . '\languages\plugins\component-theme-'. get_locale().'.mo';
    $oxy_tranlate_mo = WP_CONTENT_DIR . '\languages\plugins\oxy-translate-'. get_locale().'.mo';
    $oxygen_toolset_mo = WP_CONTENT_DIR . '\languages\plugins\oxygen-toolset-'. get_locale().'.mo';
    $oxygen_nahana_mo = WP_CONTENT_DIR . '\languages\plugins\oxy-nahana-'. get_locale().'.mo';
    

    if (!file_exists($oxy_mo)) {
        #echo "El fichero $nombre_fichero no existe";
        # direccion de idioma original
        $srcfile= plugin_dir_path(__FILE__).'../languages\oxygen-es_VE.mo';
        # direccion donde se guarda el nuevo archivo
        $dstfile= WP_CONTENT_DIR . '\languages\plugins\oxygen-'. get_locale().'.mo';

        #mkdir(dirname($dstfile), 0777, true);

        copy($srcfile, $dstfile); # si existe debe eliminarse para crearse de nuevo
        
    } # esto sera necesario cuando sean otros idiomas a parte del ingles
    /*else { # si no existe se crea
       echo "El fichero $nombre_fichero existe, debe eliminarse";
       echo 'oxygen-'. get_locale().'.mo'; 
    }*/
    if (!file_exists($ct_mo)) {
        #echo "El fichero $nombre_fichero no existe";
        # direccion de idioma original
        $srcfile_c= plugin_dir_path(__FILE__).'../languages\component-theme-es_VE.mo';
        # direccion donde se guarda el nuevo archivo
        $dstfile_c= WP_CONTENT_DIR . '\languages\plugins\component-theme-'. get_locale().'.mo';

        #mkdir(dirname($dstfile), 0777, true);

        copy($srcfile_c, $dstfile_c); # si existe debe eliminarse para crearse de nuevo
        
    } # esto sera necesario cuando sean otros idiomas a parte del ingles
    /*else { # si no existe se crea
       echo "El fichero $nombre_fichero existe, debe eliminarse";
       echo 'oxygen-'. get_locale().'.mo'; 
    }*/
    if (!file_exists($oxy_tranlate_mo)) {
        #echo "El fichero $nombre_fichero no existe";
        # direccion de idioma original
        $srcfile_ot= plugin_dir_path(__FILE__).'../languages\oxy-translate-es_VE.mo';
        # direccion donde se guarda el nuevo archivo
        $dstfile_ot= WP_CONTENT_DIR . '\languages\plugins\oxy-translate-'. get_locale().'.mo';

        #mkdir(dirname($dstfile), 0777, true);

        copy($srcfile_ot, $dstfile_ot); # si existe debe eliminarse para crearse de nuevo
        
    } # esto sera necesario cuando sean otros idiomas a parte del ingles
    /*else { # si no existe se crea
       echo "El fichero $nombre_fichero existe, debe eliminarse";
       echo 'oxygen-'. get_locale().'.mo'; 
    }*/
    if (!file_exists($oxygen_toolset_mo)) {
        #echo "El fichero $nombre_fichero no existe";
        # direccion de idioma original
        $srcfile_ts= plugin_dir_path(__FILE__).'../languages\oxygen-toolset-es_VE.mo';
        # direccion donde se guarda el nuevo archivo
        $dstfile_ts= WP_CONTENT_DIR . '\languages\plugins\oxygen-toolset-'. get_locale().'.mo';

        #mkdir(dirname($dstfile), 0777, true);

        copy($srcfile_ts, $dstfile_ts); # si existe debe eliminarse para crearse de nuevo
        
    } # esto sera necesario cuando sean otros idiomas a parte del ingles
    /*else { # si no existe se crea
       echo "El fichero $nombre_fichero existe, debe eliminarse";
       echo 'oxygen-'. get_locale().'.mo'; 
    }*/


if (!file_exists($oxygen_nahana_mo)) {
        #echo "El fichero $nombre_fichero no existe";
        # direccion de idioma original
        $srcfile_na= plugin_dir_path(__FILE__).'../languages\oxy-nahana-es_VE.mo';
        # direccion donde se guarda el nuevo archivo
        $dstfile_na= WP_CONTENT_DIR . '\languages\plugins\oxy-nahana-'. get_locale().'.mo';

        #mkdir(dirname($dstfile), 0777, true);

        copy($srcfile_na, $dstfile_na); # si existe debe eliminarse para crearse de nuevo
        
    } # esto sera necesario cuando sean otros idiomas a parte del ingles
    /*else { # si no existe se crea
       echo "El fichero $nombre_fichero existe, debe eliminarse";
       echo 'oxygen-'. get_locale().'.mo'; 
    }*/

   

  }# end class cargar_idioma_espanol


}# end class