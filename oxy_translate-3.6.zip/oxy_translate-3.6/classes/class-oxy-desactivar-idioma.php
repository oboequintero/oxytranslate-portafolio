<?php
class oxy_desactivar_idioma {
    
function eliminar_directorio() { 


	$dir = WP_CONTENT_DIR . '\languages\plugins\*';

	// Abrir un directorio, y proceder a leer su contenido
	foreach(glob($dir) as $file) {
       #echo "filename:" . $file . "<br />";
       
       #$cadena = 'oxygen';   # viene de la funcion str
	   $cadena_oxygen= substr($file, -15 ,6);

	   $cadena_component_theme= substr($file, -24 ,15);

	   $cadena_oxygen_toolset= substr($file, -23 ,14);

	   $cadena_oxy_nahana= substr($file, -19 ,10);

	   $cadena_oxy_translate= substr($file, -22 ,13);

       $cadena_locale= substr($file, -8) ;#$cadena_locale= '-en_US';  viene de la funcion str,pudienso ser cualquier local

       # y se procede a eliminar el archivo completo
	   
	   #echo $cadena_oxygen. "<br />";
	   #echo $cadena_locale. "<br />";
      
       if($cadena_oxygen == 'oxygen')# si la cadena coincide, buscamos el locale

		$filename = WP_CONTENT_DIR ."\languages\plugins/" . $cadena_oxygen .'-'. $cadena_locale;
        #echo $filename. "<br />";
		if (file_exists($filename)) {
   		 unlink($filename);
    
		}


       if($cadena_component_theme == 'component-theme')# si la cadena coincide, buscamos el locale

		$filename = WP_CONTENT_DIR ."\languages\plugins/" . $cadena_component_theme .'-'. $cadena_locale;
        #echo $filename. "<br />";
		if (file_exists($filename)) {
   		 unlink($filename);
    
		}

       if($cadena_oxygen_toolset == 'oxygen-toolset')# si la cadena coincide, buscamos el locale

		$filename = WP_CONTENT_DIR ."\languages\plugins/" . $cadena_oxygen_toolset .'-'. $cadena_locale;
        #echo $filename. "<br />";
		if (file_exists($filename)) {
   		 unlink($filename);
    
		}

		if($cadena_oxy_nahana == 'oxy-nahana')# si la cadena coincide, buscamos el locale

		$filename = WP_CONTENT_DIR ."\languages\plugins/" . $cadena_oxy_nahana .'-'. $cadena_locale;
        #echo $filename. "<br />";
		if (file_exists($filename)) {
   		 unlink($filename);
    
		}

		if($cadena_oxy_translate == 'oxy-translate')# si la cadena coincide, buscamos el locale

		$filename = WP_CONTENT_DIR ."\languages\plugins/" . $cadena_oxy_translate .'-'. $cadena_locale;
        #echo $filename. "<br />";
		if (file_exists($filename)) {
   		 unlink($filename);
    
		}


		

    }// end glob

   /*

	$filename = WP_CONTENT_DIR . '\languages\plugins\oxygen-'. get_locale().'.mo';

	if (file_exists($filename)) {
    unlink($filename);
    
	} 

	$filename = WP_CONTENT_DIR . '\languages\plugins\component-theme-'. get_locale().'.mo';

	if (file_exists($filename)) {
    unlink($filename);
    
	}

	$filename = WP_CONTENT_DIR . '\languages\plugins\oxygen-toolset-'. get_locale().'.mo';

	if (file_exists($filename)) {
    unlink($filename);
    
	}
	$filename = WP_CONTENT_DIR . '\languages\plugins\oxy-translate-'. get_locale().'.mo';

	if (file_exists($filename)) {
    unlink($filename);
    
	}
	$filename = WP_CONTENT_DIR . '\languages\plugins\oxy-nahana-'. get_locale().'.mo';

	if (file_exists($filename)) {
    unlink($filename);
    
	} */

	

	}#class eliminar_directorio

}# oxy_desactivar_idioma()