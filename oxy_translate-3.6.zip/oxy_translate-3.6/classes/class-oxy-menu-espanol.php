<?php

class oxy_menu_espanol {

function cargar_submenu_oxy() {

add_action('admin_menu', 'ct_idioma_menu2',22);

function ct_idioma_menu2() {

	
	
	add_submenu_page( 	'ct_dashboard_page', 
						'Oxy Translate', 
						'Oxy Translate', 
						'read', 
						'ct_oxy_admin2', 
						'ct_idioma_display_active2' );

} 
function ct_idioma_display_active2() {
	if ( !oxygen_vsb_current_user_can_access() )  {
        wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
    }

    include(plugin_dir_path(__FILE__)."../views/oxy-translate-admin-screen-home-espanol.php");
    
}
}# cargar_sub_menu_espanol



##################################################################333
#A PARTIR DE AQUI ESTE CODIGO NO ESTA SIENDO LLAMADO
function cargar_menu_espanol() {

############################################################
#Ruta donde se encuentran los codigos originales 

# C: wordpress\wp-content\plugins\oxygen\component-framework\admin\pages.php
###############################################################
function menu_admin_removal() { # Removiendo Menu admin en Ingles
 remove_menu_page ('ct_dashboard_page'); 
}
add_action( 'admin_menu', 'menu_admin_removal' , 1999);
################################################################
add_action('admin_menu', 'ct_dashboard_main_page_espanol', 11);

function ct_dashboard_main_page_espanol(){

	if(!oxygen_vsb_current_user_can_access()) {
		return;
	}

	$homePageView_e = add_menu_page( 	'Oxygen', // page <title>
					'Oxygen', // menu item name
					'read', // capability
					'ct_dashboard_page', // get param
					'ct_oxygen_home_page_view_espanol',
					'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48c3ZnIHdpZHRoPSIzODFweCIgaGVpZ2h0PSIzODVweCIgdmlld0JveD0iMCAwIDM4MSAzODUiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+ICAgICAgICA8dGl0bGU+VW50aXRsZWQgMzwvdGl0bGU+ICAgIDxkZXNjPkNyZWF0ZWQgd2l0aCBTa2V0Y2guPC9kZXNjPiAgICA8ZGVmcz4gICAgICAgIDxwb2x5Z29uIGlkPSJwYXRoLTEiIHBvaW50cz0iMC4wNiAzODQuOTQgMzgwLjgwNSAzODQuOTQgMzgwLjgwNSAwLjYyOCAwLjA2IDAuNjI4Ij48L3BvbHlnb24+ICAgIDwvZGVmcz4gICAgPGcgaWQ9IlBhZ2UtMSIgc3Ryb2tlPSJub25lIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+ICAgICAgICA8ZyBpZD0iT3h5Z2VuLUljb24tQ01ZSyI+ICAgICAgICAgICAgPG1hc2sgaWQ9Im1hc2stMiIgZmlsbD0id2hpdGUiPiAgICAgICAgICAgICAgICA8dXNlIHhsaW5rOmhyZWY9IiNwYXRoLTEiPjwvdXNlPiAgICAgICAgICAgIDwvbWFzaz4gICAgICAgICAgICA8ZyBpZD0iQ2xpcC0yIj48L2c+ICAgICAgICAgICAgPHBhdGggZD0iTTI5Ny41MDgsMzQ5Ljc0OCBDMjc1LjQ0MywzNDkuNzQ4IDI1Ny41NTYsMzMxLjg2IDI1Ny41NTYsMzA5Ljc5NiBDMjU3LjU1NiwyODcuNzMxIDI3NS40NDMsMjY5Ljg0NCAyOTcuNTA4LDI2OS44NDQgQzMxOS41NzMsMjY5Ljg0NCAzMzcuNDYsMjg3LjczMSAzMzcuNDYsMzA5Ljc5NiBDMzM3LjQ2LDMzMS44NiAzMTkuNTczLDM0OS43NDggMjk3LjUwOCwzNDkuNzQ4IEwyOTcuNTA4LDM0OS43NDggWiBNMjIyLjMwNCwzMDkuNzk2IEMyMjIuMzA0LDMxMi4wMzkgMjIyLjQ0NywzMTQuMjQ3IDIyMi42MzksMzE2LjQ0MSBDMjEyLjMzLDMxOS4wOTIgMjAxLjUyOCwzMjAuNTA1IDE5MC40MDMsMzIwLjUwNSBDMTE5LjAxLDMyMC41MDUgNjAuOTI5LDI2Mi40MjMgNjAuOTI5LDE5MS4wMzEgQzYwLjkyOSwxMTkuNjM4IDExOS4wMSw2MS41NTcgMTkwLjQwMyw2MS41NTcgQzI2MS43OTQsNjEuNTU3IDMxOS44NzcsMTE5LjYzOCAzMTkuODc3LDE5MS4wMzEgQzMxOS44NzcsMjA2LjgzMyAzMTcuMDIsMjIxLjk3OCAzMTEuODE1LDIzNS45OSBDMzA3LjE3OSwyMzUuMDk3IDMwMi40MDQsMjM0LjU5MiAyOTcuNTA4LDIzNC41OTIgQzI1NS45NzQsMjM0LjU5MiAyMjIuMzA0LDI2OC4yNjIgMjIyLjMwNCwzMDkuNzk2IEwyMjIuMzA0LDMwOS43OTYgWiBNMzgwLjgwNSwxOTEuMDMxIEMzODAuODA1LDg2LjA0MiAyOTUuMzkyLDAuNjI4IDE5MC40MDMsMC42MjggQzg1LjQxNCwwLjYyOCAwLDg2LjA0MiAwLDE5MS4wMzEgQzAsMjk2LjAyIDg1LjQxNCwzODEuNDMzIDE5MC40MDMsMzgxLjQzMyBDMjEyLjQ5OCwzODEuNDMzIDIzMy43MDgsMzc3LjYwOSAyNTMuNDU2LDM3MC42NTcgQzI2NS44NDUsMzc5LjY0MSAyODEuMDM0LDM4NSAyOTcuNTA4LDM4NSBDMzM5LjA0MiwzODUgMzcyLjcxMiwzNTEuMzMgMzcyLjcxMiwzMDkuNzk2IEMzNzIuNzEyLDI5Ni4wOTIgMzY4Ljk4OCwyODMuMjgzIDM2Mi41ODQsMjcyLjIxOSBDMzc0LjI1MSwyNDcuNTc1IDM4MC44MDUsMjIwLjA1OCAzODAuODA1LDE5MS4wMzEgTDM4MC44MDUsMTkxLjAzMSBaIiBpZD0iRmlsbC0xIiBmaWxsPSIjMDBCM0MxIiBtYXNrPSJ1cmwoI21hc2stMikiPjwvcGF0aD4gICAgICAgIDwvZz4gICAgPC9nPjwvc3ZnPg==' ); 

	add_action( 'load-' . $homePageView_e, 'ct_oxygen_admin_home_page_css_espanol' );
	
	add_submenu_page( 	'ct_dashboard_page', 
						'Inicio', 
						'Inicio', 
						'read', 
						'ct_dashboard_page_e',
						'ct_oxygen_home_page_view_espanol');
}

function ct_oxygen_home_page_view_espanol() {
	if ( !oxygen_vsb_current_user_can_access() )  {
        wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
    }

    include(plugin_dir_path(__FILE__)."/views/oxy-admin-screen-home-espanol.php");
    
}
function ct_oxygen_admin_home_page_css_espanol() {
	add_action( 'admin_enqueue_scripts', 'ct_oxygen_enqueue_admin_home_page_css_espanol' );
}

function ct_oxygen_enqueue_admin_home_page_css_espanol() {
	wp_enqueue_style("oxy-admin-screen-home-espanol", plugin_dir_path(__FILE__)."/css/oxy-admin-screen-home-espanol.css");

}
################################################################
function menu_removal_a() { # Removiendo Menu Export & Import en Ingles
 remove_submenu_page ('ct_dashboard_page','ct_dashboard_page'); 
}
add_action( 'admin_menu', 'menu_removal_a' , 2000);

############################################################

add_action('admin_menu', 'ct_idioma_menu',16);

function ct_idioma_menu() {

	if(!oxygen_vsb_current_user_can_access()) {
		return;
	}
	
	add_submenu_page( 	'ct_dashboard_page', 
						'Oxy Translate', 
						'Oxy Translate', 
						'read', 
						'ct_oxy_admin', 
						'ct_idioma_display_active' );

} 
function ct_idioma_display_active() {
	if ( !oxygen_vsb_current_user_can_access() )  {
        wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
    }

    include(plugin_dir_path(__FILE__)."/views/oxy-translate-admin-screen-home-espanol.php");
    
}

###############################################################
function menu_export_removal() { # Removiendo Menu Export & Import en Ingles
 remove_submenu_page ('ct_dashboard_page','ct_export_import'); 
}
add_action( 'admin_menu', 'menu_export_removal' , 2000);


###############################################################
function menu_template_removal() { # Removiendo submenu Template en Ingles
 remove_submenu_page ('ct_dashboard_page','edit.php?post_type=ct_template'); 
}
add_action( 'admin_menu', 'menu_template_removal' , 2001);

###############################################################
function menu_settings_removal() { # Removiendo submenu settings en Ingles
 remove_submenu_page ('ct_dashboard_page','oxygen_vsb_settings'); 
}
add_action( 'admin_menu', 'menu_settings_removal' , 2002);


###############################################################
add_action('admin_menu', 'ct_export_import_espanol', 15); # Agregar submenu exportar importar

function ct_export_import_espanol() {

	if(!oxygen_vsb_current_user_can_access()) {
		return;
	}
	
	add_submenu_page( 	'ct_dashboard_page', 
						'Exportar & Importar', 
						'Exportar & Importar', 
						'read', 
						'ct_export_import_espanol', 
						'ct_export_import_callback' );
}

################################################################

add_action('admin_menu', 'ct_template_espanol', 12); # agregar submenu de plantillas

function ct_template_espanol() {

	if(!oxygen_vsb_current_user_can_access()) {
		return;
	}
	
	add_submenu_page( 	'ct_dashboard_page', 
						'Plantillas', 
						'Plantillas', 
						'read', 
						'edit.php?post_type=ct_template');

	}
################################################################
function ct_admin_settings2() { # Agregar submenu de ajustes
	
	if(!oxygen_vsb_current_user_can_access()) {
		return;
	}

	$oxygen_vsb_settings = add_submenu_page(
			'ct_dashboard_page',
			'Ajustes',
			'Ajustes',
			'read',
			'oxygen_vsb_settings',
			'oxygen_vsb_options_page');

	add_submenu_page(null, 'Add 3rd Party Design Set', 'Add 3rd Party Design Set', 'manage_options', 'add_3rdp_designset', 'add_3rdp_designset_callback');
		
	add_action( 'load-' . $oxygen_vsb_settings, 'oxygen_vsb_settings_page_onload' );
}

add_action('admin_menu', 'ct_admin_settings2', 13);

#################################################################################################

}# end class cargar_menu_espanol	

}# end class