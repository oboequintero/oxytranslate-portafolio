<?php
class oxy_tabla {

	
	public static function create_table() {
        
        global $wpdb;
        
        $sql = "CREATE TABLE IF NOT EXISTS " . OXY_TABLE . "(
            id int(11) NOT NULL AUTO_INCREMENT,
            nombre varchar(50) NOT NULL,
            activo boolean NOT NULL,
            PRIMARY KEY (id)
        );";
        
        $wpdb->query( $sql );
     
     
	}
  public static function drop_table() {
        
        global $wpdb;
        
        $sql = "DROP TABLE IF EXISTS " . OXY_TABLE ;
        $wpdb->query($sql);
     
     
  }
 public static function insert_language() {

  global $wpdb;
          

  $nombre   = 'Español';
  $wpdb->query(
  $wpdb->prepare(
   "
   INSERT INTO " . OXY_TABLE . "
   ( nombre, activo )
   VALUES ( %s, %d )
   ",
   array(
         
         $nombre,
         0,
      )
   )
 );

}
}





