<?php
/*
Plugin Name:	Oxy Translate-Oxygen 3.6
Plugin URI:		https://nahanastudio.com/
Description:	Oxy Translate -Oxygen 3.6
Version:		1.0.3
Author:			Nahana Studio
Author URI:		https://nahanastudio.com/
License:		GPL-2.0+
License URI:	http://www.gnu.org/licenses/gpl-2.0.txt
Text Domain:    oxygen
Domain Path:    /languages

This plugin is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.

This plugin is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with This plugin. If not, see {URI to Plugin License}.
*/

if ( ! defined( 'WPINC' ) ) {
	die;
}
define( 'CT_PLUGIN_DIR_PATH_OXYGEN', plugin_dir_path( __FILE__ ) ); # direccion absoluta
define( 'CT_REALPATH_BASENAME_PLUGIN_OXYGEN', dirname( plugin_basename( __FILE__ ) ) . '/' ); # Direccion relativa

global $wpdb;

define( 'OXY_TABLE', "{$wpdb->prefix}oxy_translate_data" );

 require(plugin_dir_path(__FILE__)."/classes/class-oxy-tabla.php");
 require(plugin_dir_path(__FILE__)."/classes/class-oxy-borrar-tabla.php");
 require(plugin_dir_path(__FILE__)."/classes/class-oxy-menu-espanol.php");
 require(plugin_dir_path(__FILE__)."/classes/class-oxy-cargar-espanol.php");
 require(plugin_dir_path(__FILE__)."/classes/class-oxy-desactivar-idioma.php");

/**
 * Código que se ejecuta en la activación del plugin
 */
function activate_oxy_translate() {
	oxy_tabla::create_table();
	oxy_tabla::insert_language();
	
}

/**
 * Código que se ejecuta en la desactivación del plugin
 */
function deactivate_oxy_translate() {
	oxy_desactivar_idioma::eliminar_directorio();
	oxy_tabla::drop_table();
}

register_activation_hook( __FILE__, 'activate_oxy_translate' );
register_deactivation_hook( __FILE__, 'deactivate_oxy_translate' );


function run_oxy_master_idioma_espanol_al_cambiar_idioma_wp() {	
   			 $oxy_idioma_es2= new oxy_idioma_espanol;
   			 $oxy_idioma_es2->re_cargar_idioma_espanol();

			}

function run_oxy_submenu() {
    $oxy_submenu= new oxy_menu_espanol;
    $oxy_submenu->cargar_submenu_oxy();
}

run_oxy_submenu();
run_oxy_master_idioma_espanol_al_cambiar_idioma_wp();
