<div class='wrap oxygen-admin-screen-home'>
	<h1>Oxygen en Español</h1>

		<div class='oxygen-admin-screen-home-flex'>

		<div class='oxygen-admin-screen-home-left'>

			<div class='oxygen-admin-screen-home-section'>
				<h2>Agregar Nuevas Páginas</h2>
				<p>Agrega una nueva página a tu sitio, guárdalo, y luego haz click <em>Editar con Oxygen</em> para visualizar el diseño de tu página.</p>
				<a href='<?php echo admin_url('post-new.php?post_type=page');?>'>Páginas &raquo; Agregar Nuevo</a>
			</div>


			<div class='oxygen-admin-screen-home-section'>
				<h2>Personaliza tus Plantillas</h2>
				<p>Oxygen controla el diseño de tu sitio usando plantillass. Personaliza &amp; crea tus Plantillas para controlar tus headers, footers, y layouts para cualquier tipo de publicación o archivo.</p>
				<a href='<?php echo admin_url('edit.php?post_type=ct_template');?>'>Oxygen &raquo; Plantillas</a>
			</div>

			<div class='oxygen-admin-screen-home-section'>
				<h2>Accede Biblioteca de Diseños</h2>
				<p>Access Oxygen's Design Library by opening the Oxygen visual editor. Clic <em>Agregar+</em> in the top left, and then click <em>Biblioteca</em>.</p>
			</div>

			<div class='oxygen-admin-screen-home-section'>
				<h2>Ayuda, Soporte y Tutoriales</h2>
				<p>Nuevo en Oxygen? Ver más <a href='https://oxygenbuilder.com/documentation/getting-started/getting-started-tutorial/'>getting started video</a> to get up to speed.</p>

				<ul>
					<li>
						<a href='https://oxygenbuilder.com/facebook'>Facebook Group (HIGHLY recomendado)</a>
					</li>
					<li>
						<a href='https://oxygenbuilder.com/support'>Contacta a Equipo de Soporte de Oxygen</a>
					</li>
					<li>
						<a href='https://oxygenbuilder.com/slack'>Oxygen Slack Chat</a>
					</li>
					<li>
						<a href='https://oxygenbuilder.com/documentation'>Tutoriales &amp; Documentación</a>
					</li>
				</ul>


			</div>
		</div>

	<?php
		$site = get_option('ct_last_installed_default_data', false);
		global $ct_source_sites;
	?>
		<div class='oxygen-admin-screen-home-section-design-set-chooser'>

			<h3>Biblioteca de Diseños de Oxygen</h3>
			<?php if($site) { 
				$label = $site;
				if(isset($ct_source_sites[$site]) && isset($ct_source_sites[$site]['label'])) {
					$label = $ct_source_sites[$site]['label'];
				}
				?>
			<div class='oxygen-admin-screen-home-section-design-set-chooser-text'>The <?php echo esc_html($label);?> pre-built website has been installed from the Oxygen Design Library.</div>
			<?php } ?>
			<a href='<?php echo add_query_arg('page', 'ct_install_wiz', get_admin_url());?>'>Instala un<?php echo $site?'Different ':'';?>Sitio Web</a>

			<!--
			<div class='oxygen-admin-screen-home-section-design-set-chooser-text'>You can install pre-built websites in 1-click from our design library.</div>
			<a href=''>Browse Library</a>
			-->

		</div>

	</div>


</div>

