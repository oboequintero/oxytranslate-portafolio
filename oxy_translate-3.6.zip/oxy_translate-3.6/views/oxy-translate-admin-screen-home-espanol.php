<?php 
if(isset($_POST['idioma_activo']))
	{
		$idioma_activo = $_POST['idioma_activo'];
		if ($idioma_activo == 1)
		{         
			function run_oxy_master_idioma_espanol() {	
   			 $oxy_idioma_es= new oxy_idioma_espanol;
   			 $oxy_idioma_es->cargar_idioma_espanol();
			}
            run_oxy_master_idioma_espanol();
          	echo "<script type='text/javascript'>window.location=document.location.href;</script>";# Esta 
          //https://wordpress.stackexchange.com/questions/229139/refresh-page-after-form-action
         } 
         elseif ($idioma_activo == 0)
         {
			function run_oxy_desactivar_idioma() {	
   			 $oxy_desactivar_idioma= new oxy_desactivar_idioma;
   			 $oxy_desactivar_idioma->eliminar_directorio();
		 }
            run_oxy_desactivar_idioma();
            echo "<script type='text/javascript'>
          window.location=document.location.href;
          </script>";
          //https://wordpress.stackexchange.com/questions/229139/refresh-page-after-form-action

         } #elseif

    }
    
?>
<div class='wrap oxygen-admin-screen-home'>
	<h1>Oxy Translate- Oxygen en Español 1.0.6 </h1>

		<div class='oxygen-admin-screen-home-flex'>

		<div class='oxygen-admin-screen-home-left'>

			<div class='oxygen-admin-screen-home-section'>
				<h2>Cambiar Idioma de Oxygen</h2>
				<p>Selecciona el Idioma de tu preferencia y luego haz click en >> Guardar Cambios</p>


				 <form action="" method="post">

    			<div class=".oxygen-admin-screen-home-section-design-set-chooser ">
				
		              
				<select name="idioma_activo" >
				<option value="0" selected="selected">Default Language</option>
				<option value="1">Español</option>
				
				</select>
				

   			    <button type="submit">Guardar Cambios</button>
				</div>
                </form>

			</div>
		</div>

	
	</div>


</div>
